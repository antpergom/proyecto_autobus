package servidor;

import java.util.ArrayList;
import java.util.List;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.SetMultimap;

import io.netty.handler.codec.mqtt.MqttConnectReturnCode;
import io.netty.handler.codec.mqtt.MqttQoS;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.http.ClientAuth;
import io.vertx.mqtt.MqttEndpoint;
import io.vertx.mqtt.MqttServer;
import io.vertx.mqtt.MqttServerOptions;
import io.vertx.mqtt.MqttTopicSubscription;

public class MQTTServerVerticle extends AbstractVerticle{
	
	//TODO: Modificar usuario y contrase�a
	private static String NOMBRE_USUARIO = "nombre_aqui";
	private static String CONTRASENYA_USUARIO = "contrasenya_aqui";
	
	//TODO: Temas para suscribirse
	public static final String TOPIC_INFO_PARADAS = "info_paradas";
	public static final String TOPIC_AVISO_LEDS= "aviso_leds";
	
	//Esta variable guarda la lista de clientes (MqttEndpoint) subscritos a un topic (String)
	public static final SetMultimap<String, MqttEndpoint> clientes = LinkedHashMultimap.create();
	
	public void start(Promise<Void> promise) {
		MqttServerOptions opt = new MqttServerOptions();
		opt.setPort(1885);
		opt.setClientAuth(ClientAuth.REQUIRED);
		MqttServer server = MqttServer.create(vertx, opt);
		init(server);	//Inicializar servidor
	}
	
	public void init(MqttServer server) {
		//Endpoint es el handler del canal MQTT, que gestiona los eventos que se producen en �l
		server.endpointHandler(ep -> {
			System.out.println("MQTT client [" + ep.clientIdentifier() + "] resquest to connect, clean session = " + ep.isCleanSession());
			if(ep.auth().getUsername().contentEquals(NOMBRE_USUARIO) && ep.auth().getPassword().contentEquals(CONTRASENYA_USUARIO)) {
				ep.accept();
				// Las 4 acciones del canal MQTT son suscribirse, desuscribirse, publicar mensaje y desconectarse, implementados en ese orden
				handleSubscription(ep);
				handleUnsubscription(ep);
				publishHandler(ep);
				handleClientDisconnect(ep);
				

			}else {
				ep.reject(MqttConnectReturnCode.CONNECTION_REFUSED_BAD_USER_NAME_OR_PASSWORD);
			}
		}).listen(connectHandler -> {
			if(connectHandler.succeeded()) {
				System.out.println("MQTT server is listening on port " + connectHandler.result().actualPort());
			}else {
				System.out.println("Error on starting the server.");
			}
		});
	}
	
	private void handleSubscription(MqttEndpoint ep) {
		ep.subscribeHandler(sub -> {
			List<MqttQoS> grantedQoSLevels = new ArrayList<>();
			for(MqttTopicSubscription topic : sub.topicSubscriptions()) {	//Por cada uno de los canales a los que est� subscrito
				System.out.println("Subscripci�n a " + topic.topicName() + " with QoS " + topic.qualityOfService());
				grantedQoSLevels.add(topic.qualityOfService());
				clientes.put(topic.topicName(), ep);
			}
			ep.subscribeAcknowledge(sub.messageId(), grantedQoSLevels);
		});
	}


	private void handleUnsubscription(MqttEndpoint ep) {
		ep.unsubscribeHandler(unsub-> {
			for(String topic : unsub.topics()) {
				System.out.println("Unsuscribe from topic: " + topic);
				clientes.remove(topic, ep);
			}
			ep.unsubscribeAcknowledge(unsub.messageId());
		});
		
	}
	
	//Tanto clientes como cada uno de lo mensajes tiene un identificador �nico
	private void publishHandler(MqttEndpoint ep) {
		ep.publishHandler(message -> {
			if(message.qosLevel() == MqttQoS.AT_LEAST_ONCE) {	//AT_LEAST_ONCE sobrecarga menos el servidor
				String topicName = message.topicName();
				System.out.println("New message published in " + topicName);
				for(MqttEndpoint subscribed: clientes.get(topicName)) {
					//el mensaje se mantiene en el servidor hasta que se entrega a todos los usuarios
					subscribed.publish(message.topicName(), message.payload(), message.qosLevel(), message.isDup(), message.isRetain());
				}
				ep.publishAcknowledge(message.messageId());
				
			}else if(message.qosLevel() == MqttQoS.EXACTLY_ONCE) {
				ep.publishRelease(message.messageId());
			}
			
		}).publishReleaseHandler(messageId -> {
			ep.publishComplete(messageId);
		});
		
	}
	
	private void handleClientDisconnect(MqttEndpoint ep) {
		ep.disconnectHandler(handler -> {
			System.out.println("The remote client has closed the connection.");
		});
		
	}





	
	

}
