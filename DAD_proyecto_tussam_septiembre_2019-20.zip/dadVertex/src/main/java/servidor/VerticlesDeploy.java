package servidor;

import java.util.ArrayList;
import java.util.List;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;

public class VerticlesDeploy extends AbstractVerticle {

	
	
	//TODO: Configurar servidor HTTP con un dominio concreto
	public void start(Future<Void> startFuture) {
		//A�adir aqu� los verticles necesarios para no tocar m�s c�digo abajo		
		//desplegarVerticles(new ArrayList<>());
		vertx.deployVerticle(DatabaseVerticle.class.getName());
		vertx.deployVerticle(TussamTelegramBot.class.getName());
	}
	

	
	
}
