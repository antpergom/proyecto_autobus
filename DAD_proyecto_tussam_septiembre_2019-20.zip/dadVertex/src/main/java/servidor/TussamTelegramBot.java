package servidor;

import io.vertx.core.AbstractVerticle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.schors.vertx.telegram.bot.LongPollingReceiver;
import org.schors.vertx.telegram.bot.TelegramBot;
import org.schors.vertx.telegram.bot.TelegramOptions;
import org.schors.vertx.telegram.bot.api.methods.SendMessage;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;


public class TussamTelegramBot extends AbstractVerticle {
	private TelegramBot bot;
	public void start(Promise<Void> future) {

		TelegramOptions telegramOptions = new TelegramOptions()
				.setBotName("TussamDAD_bot")
				.setBotToken("1327050269:AAGzXCngQYESsiFqjpAgGcQ3DXpnOPoh36Q");
		
		//El bot est� siempre a la escucha es decir es bloqueante, para eso usamos un PollingReceiver
		//que lo lleva a un segundo plano,y nos suscribimos al evento en un update
		bot = TelegramBot.create(vertx, telegramOptions)
				.receiver(new LongPollingReceiver().onUpdate(handler -> {
					String texto = handler.getMessage().getText().toLowerCase();
					texto.replaceAll("\\s","");
					if (texto.contains("hola")) {
						bot.sendMessage(new SendMessage()
								.setText("Hola " + handler.getMessage().getFrom().getFirstName() + " "
										+ "bienvenido al bot en fase de desarrolo de tussam. Para ver la lista"
										+ " de comandos que est� a su disposici�n, escriba /ayuda")
								.setChatId(handler.getMessage().getChatId()));
					} else if (texto.contains("ayuda")) {
						//Obtener el tiempo de una ubicaci�n concreta
						bot.sendMessage(new SendMessage()
								.setText("La lista de comandos a su disposici�n es:\n"
										+ "/Autobuses,\n"
										+ "ocupaci�n:id_Autobus,\n"
										+ "temperatura:id_Autobus,\n"
										+ "humedad:id_Autobus")
								.setChatId(handler.getMessage().getChatId()));
						
					}else if(texto.contains("autobuses")) {
						WebClient client = WebClient.create(vertx);
						client.get(8080, "localhost","/tussam_api/dispositivos_autobus/")
							.send(ar -> {
								if (ar.succeeded()) {								
									HttpResponse<Buffer> response = ar.result(); 
									JsonArray jArray = response.bodyAsJsonArray();
									List<Integer> listaDeAutobuses = new ArrayList<>();
									for(int i = 0;i<jArray.size();i++) {
										listaDeAutobuses.add(jArray.getJsonObject(i).getInteger("iddispositivo_autobus"));
									}
									String res = "La lista de autobuses es: "+ listaDeAutobuses; 
									bot.sendMessage(new SendMessage()
											.setText(res)
											.setChatId(handler.getMessage().getChatId()));
										
								}else{
									bot.sendMessage(new SendMessage()
											.setText("Vaya, algo ha salido mal")
											.setChatId(handler.getMessage().getChatId()));
								}
							});
					}else if(texto.matches("^ocupaci�n:\\d+")) {
						List<String> trozos = Arrays.asList(texto.split(":"));
						int idDispositivoAutobus = Integer.parseInt(trozos.get(1));
						WebClient client = WebClient.create(vertx);
						client.get(8080, "localhost","/tussam_api/dispositivos_autobus/"+idDispositivoAutobus)
							.send(ar -> {
								if (ar.succeeded()) {								
									HttpResponse<Buffer> response = ar.result(); 
									JsonObject object = response.bodyAsJsonObject();
									float ocupacion = object.getInteger("ocupacion");
									float capacidad  = object.getInteger("capacidad");
									int porcentajeOcupacion = (int)((ocupacion/capacidad)*100);
									String res = "El autob�s se encuentra al "+porcentajeOcupacion+"% de ocupaci�n"; 
									bot.sendMessage(new SendMessage()
											.setText(res)
											.setChatId(handler.getMessage().getChatId()));
										
								}else{
									bot.sendMessage(new SendMessage()
											.setText("Vaya, algo ha salido mal")
											.setChatId(handler.getMessage().getChatId()));
								}
							});
					}else if(texto.matches("^temperatura:\\d+")) {
						List<String> trozos = Arrays.asList(texto.split(":"));
						int idDispositivoAutobus = Integer.parseInt(trozos.get(1));
						WebClient client = WebClient.create(vertx);
						client.get(8080, "localhost","/tussam_api/sensores/valorsensores/temperatura/"+idDispositivoAutobus)
							.send(ar -> {
								if (ar.succeeded()) {
									HttpResponse<Buffer> response = ar.result(); 
									JsonObject object = response.bodyAsJsonObject();
									float temp = object.getFloat("valor(�C)");
									String res = "La temperatura del autob�s es de: "+temp+"�C";
									bot.sendMessage(new SendMessage()
											.setText(res)
											.setChatId(handler.getMessage().getChatId()));
										
								}else{
									bot.sendMessage(new SendMessage()
											.setText("Vaya, algo ha salido mal")
											.setChatId(handler.getMessage().getChatId()));
								}
							});
					}else if(texto.matches("^humedad:\\d+")) {
						List<String> trozos = Arrays.asList(texto.split(":"));
						int idDispositivoAutobus = Integer.parseInt(trozos.get(1));
						WebClient client = WebClient.create(vertx);
						client.get(8080, "localhost","/tussam_api/sensores/valorsensores/humedad/"+idDispositivoAutobus)
							.send(ar -> {
								if (ar.succeeded()) {
									HttpResponse<Buffer> response = ar.result(); 
									JsonObject object = response.bodyAsJsonObject();
									float hum = object.getFloat("valor(HR%)");
									String res = "El porcentaje de humedad relativa del autob�s es de: "+hum+"%HR";
									bot.sendMessage(new SendMessage()
											.setText(res)
											.setChatId(handler.getMessage().getChatId()));
										
								}else{
									bot.sendMessage(new SendMessage()
											.setText("Vaya, algo ha salido mal")
											.setChatId(handler.getMessage().getChatId()));
								}
							});
					}else {
						bot.sendMessage(new SendMessage()
								.setText("Vaya, parece que no le he entendido. Escriba /ayuda para conocer mis funciones")
								.setChatId(handler.getMessage().getChatId()));
					}
					
				}));
		
		bot.start();
	}
	
	public boolean esN�mero(String strNum) {
	    if (strNum == null) {
	        return false;
	    }
	    try {
	        double d = Integer.parseInt(strNum);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
}
