package clases;

public enum TipoSensor {
	Salida,
	Entrada
}
